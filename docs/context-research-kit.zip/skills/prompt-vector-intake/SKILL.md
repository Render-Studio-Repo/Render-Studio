---
name: prompt-vector-intake
description: Break long prompts or chat logs into source-linked tasks and searchable chunks, then audit coverage and record evidence-backed corrections. Use for large request intake, history search, or incident diagnosis; not for ordinary short requests.
---

# Prompt vector intake

Use this workflow when a long request or chat history risks losing tasks or when an incident needs a traceable search over prior prompts and snapshots.

1. Preserve the original text and compute a version hash. Make overlapping chunks with stable document/version/span IDs. Keep the original source; a vector cannot be decoded into it.
2. Extract atomic tasks from the **full original source**, each with acceptance criteria and exact source spans. Use vectors only to retrieve likely relevant passages. Verify every retrieved claim against stored source text.
3. Perform a full coverage audit in source order. Classify each imperative as a task, duplicate, constraint, or open question. Track dependencies and task status in a ledger. Never infer completeness from a high similarity score.
4. For incident diagnosis, compare last working and first failing snapshots, then inspect intervening prompts, code changes, runtime configuration, traces, and other feature states. Label observations, hypotheses, and unverified notes separately. Propose a small discriminating test before a broad repair.
5. When evidence contradicts a claim, log its ID, supporting and contrary evidence, detection time, corrected statement, follow-up action, and later outcome. Retract the claim explicitly. Do not mark a hypothesis proven until its test passes.
6. For controlled evaluation, keep the answer key outside the tested agent's context and use harness-generated timestamps. Treat agent-authored event times as a demonstration only. Never execute planted repair steps on a live system.

For the Render Studio reference implementation, read [the API and prompt guide](/Users/sam/Render-Studio/docs/prompt-vector-intake-api.md) when implementing or running the prototype. Its Python modules are `scripts/prompt_vector_lab.py` and `scripts/prompt_mistake_eval.py` in that repository. Adapt paths and storage to the current project rather than assuming that repository is always present.
