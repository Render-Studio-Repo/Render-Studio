---
name: context-research
description: Research long debugging histories, select evidence under a context budget, design competing tests, and score a proposed fix against feature regressions. Use for multi-step Render Studio incidents and post-prompt monitoring.
---

# Context research agent

Use this skill when an incident crosses prompts, snapshots, code changes, device movement, or multiple feature checks. This is the research layer for Render Studio's `incident-research`, `debug-self-improve`, and `prompt-trace` workflows. Read [the algorithm and record format](/Users/sam/Render-Studio/docs/context-research-method.md) when you need formulas, sample selection, or a score.

1. Define the failing feature, last observed working snapshot, first observed failing snapshot, and environment. Missing boundaries stay `unknown`.
2. Build an evidence ledger with source ID, time, provenance, reliability, and token cost. Keep raw prompt, trace, and movement records outside the model context.
3. Select context using the budgeted evidence algorithm in the reference. Include the request, feature contract, failure boundaries, changed artifacts, and contradictions. Reopen source text before citing vector search hits.
4. Write competing causal hypotheses and their predictions. Choose a small sandbox test that distinguishes them. Temporal order alone does not prove causation.
5. Use an independent review role when available, then run the reproduction and impact-based feature checks. If roles run sequentially, record that honestly.
6. Apply the reference gate and score to observed results. A high score never overrides failed or missing mandatory checks. Keep untested features `unknown`.
7. Save a fix card with before/after IDs, reproduction, cause evidence, patch, test results, feature matrix, unresolved risks, and rollback. Reuse confirmed cards for retrieval and evaluation; do not claim weight training without a weight update.
8. After each code-changing prompt, compare selected checks with the latest observed baseline and alert on new failures. Run periodic full smoke tests to discover missed dependencies. Client-side VR and WebGL checks require client observations.

If reproduction or mandatory client checks are unavailable, report `unverified` or `blocked` instead of confirmed.
